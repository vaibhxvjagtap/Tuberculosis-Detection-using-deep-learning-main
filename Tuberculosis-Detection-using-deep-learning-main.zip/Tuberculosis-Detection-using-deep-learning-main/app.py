# app.py
import shutil
from pathlib import Path
import webbrowser

from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from scripts.inference_pipeline import TBDetectionPipeline

# --------- CONFIG ---------
XCEPTION_MODEL = "src/training/models/xception_classification/xception_best.h5"
UNET_MODEL = "models/unet_segmentation/unet_fold1_best.h5"
UPLOAD_DIR = Path("uploads")
PRED_DIR = Path("results/predictions")
FRONTEND_FILE = Path("index.html")   # your UI file
HOST = "127.0.0.1"
PORT = 8000
# --------------------------


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR.mkdir(exist_ok=True)
PRED_DIR.mkdir(parents=True, exist_ok=True)

# serve prediction images (heatmap, overlay, etc.) under /results/...
app.mount("/results", StaticFiles(directory=str(PRED_DIR.parent)), name="results")

pipeline = TBDetectionPipeline(
    xception_model_path=XCEPTION_MODEL,
    unet_model_path=UNET_MODEL,
)


@app.post("/analyze")
async def analyze_image(file: UploadFile = File(...)):
    dest = UPLOAD_DIR / file.filename
    with dest.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    report = pipeline.run_complete_analysis(
        image_path=str(dest),
        save_visualizations=True,
        output_dir=str(PRED_DIR),
    )

    cls = report["classification"]
    diag = cls["diagnosis"]
    conf = float(cls["confidence"])

    damage = report.get("damage_analysis", {})
    overall = float(damage.get("overall_damage_percentage", 0.0))
    lobe = damage.get("lobe_damage", {})
    left_pct = float(lobe.get("left_lobe", 0.0))
    right_pct = float(lobe.get("right_lobe", 0.0))

    # last overlay generated
    overlays = sorted(PRED_DIR.glob("tb_analysis_*_overlay.png"))
    overlay_rel = ""
    overlay_url = ""
    if overlays:
        last = overlays[-1]
        # relative path under /results mount
        overlay_rel = last.relative_to(PRED_DIR.parent).as_posix()
        overlay_url = f"http://{HOST}:{PORT}/results/{overlay_rel}"

    if diag != "Active TB":
        return JSONResponse(
            {
                "diagnosis": diag,
                "confidence": conf,
                "is_tb": False,
                "overlay_image_url": overlay_url,
            }
        )

    return JSONResponse(
        {
            "diagnosis": "TB Positive",
            "confidence": conf,
            "is_tb": True,
            "overall_damage_percent": overall,
            "left_lobe_percent": left_pct,
            "right_lobe_percent": right_pct,
            "overlay_image_url": overlay_url,
        }
    )


def main():
    if FRONTEND_FILE.exists():
        webbrowser.open_new_tab(FRONTEND_FILE.resolve().as_uri())
    uvicorn.run(app, host=HOST, port=PORT)


if __name__ == "__main__":
    main()
