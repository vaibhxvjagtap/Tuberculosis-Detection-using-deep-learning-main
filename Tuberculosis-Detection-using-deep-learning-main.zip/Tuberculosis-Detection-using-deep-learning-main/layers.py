# print_xception_layers.py
import tensorflow as tf

MODEL_PATH = "src/training/models/xception_classification/xception_best.h5"

model = tf.keras.models.load_model(MODEL_PATH)
model.summary()

print("\nLayer names:")
for i, layer in enumerate(model.layers):
    print(i, layer.name, type(layer))
