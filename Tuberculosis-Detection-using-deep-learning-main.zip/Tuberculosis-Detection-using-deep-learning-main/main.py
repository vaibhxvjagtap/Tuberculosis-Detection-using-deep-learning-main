#!/usr/bin/env python3
"""
TB Detection Project - Main Entry Point
Following Sharma et al. 2024 Methodology
"""

import sys
from pathlib import Path
import tensorflow as tf

# Project setup
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

print("=" * 80)
print("TB DETECTION PROJECT - FOLLOWING SHARMA ET AL. 2024")
print("=" * 80)

# GPU Check
print("\n   GPU Information:")
gpus = tf.config.list_physical_devices('GPU')
print(f"   Number of GPUs: {len(gpus)}")
for gpu in gpus:
    print(f"   - {gpu}")

print("\n" + "=" * 80)
print("CHOOSE WHAT TO RUN:")
print("=" * 80)
print("\n1. Train UNet Segmentation Model (5-fold CV, 704 images)")
print("2. Train Xception Classification Model (1400 images)")
print("3. Run Full Pipeline (1 + 2)")
print("4. Exit")

choice = input("\nEnter your choice (1-4): ").strip()

if choice == '1':
    print("\n>>> Starting UNet training (Segmentation)...")
    from src.training.train_segmentation import train_unet_5fold
    train_unet_5fold()

elif choice == '2':
    print("\n>>> Starting Xception training (Classification)...")
    from src.training.train_classification import train_xception
    train_xception()

elif choice == '3':
    print("\n>>> Starting full pipeline...")
    print("\n[1/2] Training UNet (Segmentation)...")
    from src.training.train_segmentation import train_unet_5fold
    train_unet_5fold()

    print("\n[2/2] Training Xception (Classification)...")
    from src.training.train_classification import train_xception
    train_xception()

    print("\n" + "=" * 80)
    print("✅ FULL PIPELINE COMPLETE!")
    print("=" * 80)

else:
    print("Exiting...")
