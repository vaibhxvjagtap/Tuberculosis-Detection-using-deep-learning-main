import os
import sys
import numpy as np
from tensorflow.keras.models import load_model
from PIL import Image
import cv2

# Handle custom dice_coefficient etc. if present
from src.training.losses import dice_coefficient, jaccard_index

def preprocess_image(image_path):
    image = Image.open(image_path).convert("L")
    image = image.resize((224, 224))  # use UNet's input shape
    img_array = np.array(image) / 255.0
    img_array = np.expand_dims(img_array, axis=-1)  # add channel dim: (224,224,1)
    img_array = np.expand_dims(img_array, axis=0)  # shape (1, H, W, 1)
    return img_array

def predict_mask(model_path, image_array):
    custom_objects = {'dice_coefficient': dice_coefficient, 'jaccard_index': jaccard_index}
    model = load_model(model_path, custom_objects=custom_objects)
    mask = model.predict(image_array)[0, :, :, 0]
    mask = (mask > 0.5).astype(np.uint8) * 255
    return mask

if __name__ == "__main__":
    image_path = sys.argv[1]
    model_path = 'models/unet_segmentation/unet_fold3_best.h5'  # update to your best checkpoint
    image_array = preprocess_image(image_path)
    mask = predict_mask(model_path, image_array)
    input_file = image_path
    base, ext = os.path.splitext(input_file)
    output_path = base + "_mask" + ext  
    cv2.imwrite(output_path, mask)
    print(f"Mask saved to {output_path}")
