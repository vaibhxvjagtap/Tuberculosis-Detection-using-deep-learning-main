# scripts/inference_pipeline.py
"""
Complete TB Detection Inference Pipeline
Classification + Segmentation + Damage Quantification + JSON report.
(Heatmap/Grad-CAM hooks can be added later on top of this.)
"""

import sys
import json
from pathlib import Path
from datetime import datetime

import numpy as np
import tensorflow as tf
from PIL import Image
import cv2

# Add project root to path so `src` is importable
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.evaluation.damage_quantifier import DamageQuantifier
from src.evaluation.heatmap_generator import HeatmapGenerator  # minimal stub for now


class TBDetectionPipeline:
    """
    Complete TB detection and diagnosis pipeline.
    """

    def __init__(self, xception_model_path, unet_model_path=None):
        print("\n" + "=" * 80)
        print("INITIALIZING TB DETECTION PIPELINE")
        print("=" * 80 + "\n")

        # 1) Load classifier
        print("[1/3] Loading Xception classification model...")
        self.xception_model = tf.keras.models.load_model(xception_model_path)
        print(f"  ✓ Loaded from {xception_model_path}")

        # 2) Load UNet (optional but recommended)
        print("\n[2/3] Loading UNet segmentation model...")
        if unet_model_path:
            try:
                from src.training.losses import dice_coefficient, jaccard_index

                self.unet_model = tf.keras.models.load_model(
                    unet_model_path,
                    custom_objects={
                        "dice_coefficient": dice_coefficient,
                        "jaccard_index": jaccard_index,
                    },
                )
                print(f"  ✓ Loaded from {unet_model_path}")
            except Exception as e:
                print(f"  ⚠ Failed to load UNet model: {e}")
                self.unet_model = None
        else:
            print("  ⚠ UNet model path not provided. Segmentation disabled.")
            self.unet_model = None

        # 3) Analysis tools
        print("\n[3/3] Initializing analysis tools...")
        self.damage_quantifier = DamageQuantifier(unet_model=self.unet_model)
        self.heatmap_generator = HeatmapGenerator()  # currently a no-op

        self.class_names = {0: "Healthy", 1: "Sick (Non-TB)", 2: "Active TB"}

        print("\n✓ Pipeline initialized successfully!\n")

    # ---------------- Core steps ----------------

    def load_and_preprocess_image(self, image_path, img_size=224):
        """
        Load X-ray, return:
          - img_array: (1,224,224,3) float32 in [0,1] for Xception
          - img_original: 2D uint8 original resolution for segmentation/visualization
        """
        img = Image.open(image_path).convert("L")
        img_original = np.array(img)  # H×W, uint8

        img_resized = img.resize((img_size, img_size))
        arr = np.array(img_resized, dtype=np.float32) / 255.0
        arr = np.stack([arr] * 3, axis=-1)  # 3-channel
        arr = np.expand_dims(arr, axis=0)   # batch dim

        return arr, img_original

    def classify_image(self, image_array):
        """
        Run Xception classifier.
        """
        preds = self.xception_model.predict(image_array, verbose=0)[0]
        pred_class = int(np.argmax(preds))
        confidence = float(preds[pred_class])

        return {
            "class": pred_class,
            "class_name": self.class_names[pred_class],
            "confidence": confidence,
            "all_predictions": {
                self.class_names[i]: float(preds[i]) for i in range(3)
            },
        }

    def segment_lungs(self, image_original):
        """
        Segment lungs using UNet; returns 2D mask same size as original (0 or 255).
        """
        if self.unet_model is None:
            print("⚠ UNet model not available. Skipping segmentation.")
            return None

        # Resize original to 224x224 grayscale in [0,1]
        img_resized = Image.fromarray(image_original).resize((224, 224))
        arr = np.array(img_resized, dtype=np.float32) / 255.0
        arr = np.expand_dims(arr, axis=(0, -1))  # (1,224,224,1)

        mask_small = self.unet_model.predict(arr, verbose=0)[0, :, :, 0]
        mask_small = (mask_small > 0.5).astype(np.uint8) * 255

        h, w = image_original.shape[:2]
        mask = cv2.resize(mask_small, (w, h), interpolation=cv2.INTER_NEAREST)
        return mask

    def analyze_damage(self, lung_mask):
        """
        Use DamageQuantifier to compute:
          - overall_damage_percentage
          - lobe_damage
          - regional_damage
        """
        if lung_mask is None:
            return None
        return self.damage_quantifier.quantify_damage(lung_mask)

    def generate_visualizations(
        self, image_original, lung_mask, damage_results, output_dir="results/predictions"
    ):
        """
        Placeholder visualization hook.
        Currently: if HeatmapGenerator is implemented, call it here.
        """
        if lung_mask is None or damage_results is None:
            return None

        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_base = output_dir / f"tb_analysis_{timestamp}"

        # If your HeatmapGenerator does nothing yet, this will just be a no-op.
        self.heatmap_generator.save_visualization(
            image_original, lung_mask, damage_results, output_base
        )
        return output_base

    def generate_report(
        self, image_path, classification_results, damage_results, output_dir="results/predictions"
    ):
        """
        Build dict with classification and damage analysis.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        report = {
            "timestamp": datetime.now().isoformat(),
            "input_image": str(image_path),
            "classification": {
                "diagnosis": classification_results["class_name"],
                "confidence": classification_results["confidence"],
                "all_probabilities": classification_results["all_predictions"],
            },
        }
        if damage_results:
            report["damage_analysis"] = damage_results

        return report

    # ---------------- Orchestration ----------------

    def run_complete_analysis(
        self, image_path, save_visualizations=True, output_dir="results/predictions"
    ):
        print("\n" + "=" * 80)
        print("RUNNING COMPLETE TB DETECTION ANALYSIS")
        print("=" * 80 + "\n")

        image_path = Path(image_path)

        # 1) Load
        print(f"[1/5] Loading image: {image_path.name}")
        img_array, img_original = self.load_and_preprocess_image(image_path)
        print("  ✓ Image loaded and preprocessed")

        # 2) Classify
        print("\n[2/5] Classifying image...")
        cls = self.classify_image(img_array)
        print(
            f"  ✓ Classification: {cls['class_name']}\n"
            f"    Confidence: {cls['confidence']:.4f}"
        )

        lung_mask = None
        damage_results = None

        # 3–5) If Active TB, segment + analyze + visualize
        if cls["class"] == 2:
            print("\n[3/5] Segmenting lungs...")
            lung_mask = self.segment_lungs(img_original)

            if lung_mask is not None:
                print("\n[4/5] Analyzing lung damage...")
                damage_results = self.analyze_damage(lung_mask)
                self.damage_quantifier.print_damage_report(
                    damage_results, classification_result=cls["class_name"]
                )

            if save_visualizations and lung_mask is not None:
                print("\n[5/5] Generating visualizations...")
                self.generate_visualizations(
                    img_original, lung_mask, damage_results, output_dir
                )
                print("  ✓ Visualizations generated")
        else:
            print("\n[3-5/5] No TB detected. Skipping segmentation + damage analysis.")

        # Report
        print("\nGenerating diagnosis report...")
        report = self.generate_report(image_path, cls, damage_results, output_dir)

        report_path = (
            Path(output_dir) / f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        )
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2)

        print(f"  ✓ Report saved to {report_path}")
        print("\n" + "=" * 80)
        print("✅ ANALYSIS COMPLETE")
        print("=" * 80 + "\n")

        return report


def main():
    """
    Example usage.
    Update paths as needed.
    """
    XCEPTION_MODEL = "src/training/models/xception_classification/xception_best.h5"
    UNET_MODEL = "models/unet_segmentation/unet_fold1_best.h5"
    IMAGE_PATH = "tb0057.png"
    OUTPUT_DIR = "results/predictions"

    pipeline = TBDetectionPipeline(
        xception_model_path=XCEPTION_MODEL,
        unet_model_path=UNET_MODEL,
    )

    report = pipeline.run_complete_analysis(
        image_path=IMAGE_PATH,
        save_visualizations=True,
        output_dir=OUTPUT_DIR,
    )

    print("\nDIAGNOSIS SUMMARY:")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
