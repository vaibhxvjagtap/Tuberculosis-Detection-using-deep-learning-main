import os
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / 'data'
MODELS_DIR = PROJECT_ROOT / 'models'
RESULTS_DIR = PROJECT_ROOT / 'results'

# Create necessary directories
for directory in [MODELS_DIR, RESULTS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# Dataset paths
SEGMENTATION_DATA = DATA_DIR / 'Lung_Segmentation'
MONTGOMERY_DATA = DATA_DIR / 'montgomery'
SHENZHEN_DATA = DATA_DIR / 'shenzhen'
TBX11K_DATA = DATA_DIR / 'tbx11k'

# UNet Configuration (from Sharma et al. 2024)
UNET_CONFIG = {
    'input_shape': (224, 224, 1),
    'epochs': 100,
    'batch_size': 4,
    'learning_rate': 0.001,
    'loss': 'binary_crossentropy',
    'dropout': 0.25,
    'num_folds': 5,
    'train_ratio': 0.70,
    'val_ratio': 0.20,
    'test_ratio': 0.10,
}

# Xception Configuration (from Sharma et al. 2024)
XCEPTION_CONFIG = {
    'input_shape': (224, 224, 3),
    'num_classes': 2,
    'epochs': 100,
    'batch_size': 8,
    'learning_rate': 0.001,
    'loss': 'categorical_crossentropy',
    'dropout': 0.25,
    'train_ratio': 0.80,
    'val_ratio': 0.10,
    'test_ratio': 0.10,
}

# Image settings
IMAGE_SIZE = 224

print("✅ Configuration loaded successfully!")
