import os
import cv2
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split, KFold
from src.config import *


class SegmentationDataLoader:
    """Load data for UNet segmentation"""

    def __init__(self, data_dir=SEGMENTATION_DATA):
        self.data_dir = Path(data_dir)
        self.image_dir = self.data_dir / 'CXR_png'
        self.mask_dir = self.data_dir / 'masks'

    def load_data(self):
        """
        Load all images and masks

        Returns:
            images: numpy array (n, 224, 224, 1)
            masks: numpy array (n, 224, 224, 1)
        """
        images = []
        masks = []

        # Get all image files
        image_files = sorted(os.listdir(self.image_dir))

        for img_file in image_files:
            # Load image
            img_path = self.image_dir / img_file
            img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
            img = cv2.resize(img, (IMAGE_SIZE, IMAGE_SIZE))
            img = img / 255.0  # Normalize to [0, 1]
            img = np.expand_dims(img, axis=-1)  # Add channel dimension

            # Load corresponding mask
            mask_path = self.mask_dir / img_file
            if mask_path.exists():
                mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
                mask = cv2.resize(mask, (IMAGE_SIZE, IMAGE_SIZE))
                mask = (mask > 127).astype(np.float32)  # Convert to binary
                mask = np.expand_dims(mask, axis=-1)

                images.append(img)
                masks.append(mask)

        return np.array(images), np.array(masks)

    def get_kfold_splits(self, images, masks, n_splits=5, seed=42):
        """
        Get K-Fold cross-validation splits

        Returns:
            List of (train_idx, val_idx) tuples for each fold
        """
        kfold = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
        splits = []

        for train_idx, val_idx in kfold.split(images):
            splits.append((train_idx, val_idx))

        return splits


class ClassificationDataLoader:
    """Load data for Xception classification"""

    def __init__(self, data_dir=TBX11K_DATA):
        self.data_dir = Path(data_dir)
        self.image_dir = self.data_dir / 'images'

    def load_data(self):
        """
        Load TBX11K dataset

        Returns:
            images: numpy array
            labels: numpy array (0=normal, 1=TB)
        """
        images = []
        labels = []

        # Class mapping
        class_mapping = {
            'healthy': 0,
            'sick_but_non_tb': 0,  # Also normal for binary classification
            'active_tb': 1,
            'latent_tb': 1,
            'uncertain_tb': 1,
        }

        # Load images from each class folder
        for class_name, class_label in class_mapping.items():
            class_dir = self.image_dir / class_name
            if class_dir.exists():
                for img_file in os.listdir(class_dir):
                    # Load image
                    img_path = class_dir / img_file
                    img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
                    img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)  # Convert to RGB
                    img = cv2.resize(img, (IMAGE_SIZE, IMAGE_SIZE))
                    img = img / 255.0  # Normalize

                    images.append(img)
                    labels.append(class_label)

        return np.array(images), np.array(labels)


# Usage example
if __name__ == "__main__":
    # Load segmentation data
    seg_loader = SegmentationDataLoader()
    seg_images, seg_masks = seg_loader.load_data()
    print(f"Segmentation: {seg_images.shape}, {seg_masks.shape}")

    # Load classification data
    clf_loader = ClassificationDataLoader()
    clf_images, clf_labels = clf_loader.load_data()
    print(f"Classification: {clf_images.shape}, {clf_labels.shape}")
