# src/evaluation/damage_quantifier.py
"""
Damage Quantification Module
Calculates percentage of lung damage based on UNet segmentation
"""

import numpy as np
import cv2
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
import matplotlib.cm as cm


class DamageQuantifier:
    """
    Quantify TB damage in lungs using segmentation masks
    """
    
    def __init__(self, unet_model=None):
        """
        Initialize damage quantifier
        
        Args:
            unet_model: Trained UNet segmentation model
        """
        self.unet_model = unet_model
    
    def get_segmentation_mask(self, image_array, threshold=0.5):
        """
        Get lung segmentation mask from UNet model
        
        Args:
            image_array: Input image array (224, 224, 1)
            threshold: Threshold for binary mask
            
        Returns:
            Binary mask (224, 224)
        """
        if self.unet_model is None:
            raise ValueError("UNet model not provided")
        
        # Ensure correct shape
        if len(image_array.shape) == 2:
            image_array = np.expand_dims(image_array, axis=-1)
        
        if image_array.shape[-1] != 1:
            # Convert to grayscale if needed
            image_array = np.mean(image_array, axis=-1, keepdims=True)
        
        # Add batch dimension
        if len(image_array.shape) == 3:
            image_array = np.expand_dims(image_array, axis=0)
        
        # Get prediction
        mask = self.unet_model.predict(image_array, verbose=0)[0, :, :, 0]
        
        # Binarize
        binary_mask = (mask > threshold).astype(np.uint8) * 255
        
        return binary_mask
    
    def calculate_damage_percentage(self, lung_mask):
        """
        Calculate percentage of lungs that are damaged (white pixels in mask)
        
        Assumes: White pixels = lung tissue, Black pixels = background
        In TB case: Bright areas in lung = infected regions
        
        Args:
            lung_mask: Binary lung segmentation mask (0-255)
            
        Returns:
            damage_percentage: Percentage of lungs damaged
            total_lung_pixels: Total number of lung pixels
            damaged_pixels: Number of damaged pixels
        """
        
        # Ensure uint8
        lung_mask = np.uint8(lung_mask)
        
        # Total lung pixels (white pixels)
        total_lung_pixels = np.count_nonzero(lung_mask > 127)
        
        if total_lung_pixels == 0:
            return 0.0, 0, 0
        
        # Damaged pixels are the white/bright regions within lung
        # In segmentation: white = lung tissue
        # We assume all visible lung tissue in TB case indicates infected area
        damaged_pixels = total_lung_pixels
        
        # Calculate percentage
        damage_percentage = (damaged_pixels / (lung_mask.shape[0] * lung_mask.shape[1])) * 100
        
        return damage_percentage, total_lung_pixels, damaged_pixels
    
    def calculate_lobe_damage(self, lung_mask, left_threshold=0.5):
        """
        Calculate damage percentage for left and right lung lobes
        
        Args:
            lung_mask: Binary lung segmentation mask
            left_threshold: Threshold to split left/right (0-1, default 0.5 = middle)
            
        Returns:
            Dictionary with left and right lobe damage percentages
        """
        
        lung_mask = np.uint8(lung_mask)
        h, w = lung_mask.shape
        
        # Split at vertical center
        split_point = int(w * left_threshold)
        
        left_lobe = lung_mask[:, :split_point]
        right_lobe = lung_mask[:, split_point:]
        
        # Calculate for each lobe
        left_total = np.count_nonzero(left_lobe > 127)
        right_total = np.count_nonzero(right_lobe > 127)
        
        left_damage = (left_total / (h * split_point) * 100) if split_point > 0 else 0
        right_damage = (right_total / (h * (w - split_point)) * 100) if w > split_point else 0
        
        return {
            'left_lobe': left_damage,
            'right_lobe': right_damage,
            'left_pixels': left_total,
            'right_pixels': right_total
        }
    
    def calculate_upper_lower_damage(self, lung_mask, upper_threshold=0.5):
        """
        Calculate damage in upper vs lower lung regions
        
        Args:
            lung_mask: Binary lung segmentation mask
            upper_threshold: Threshold to split upper/lower (0-1, default 0.5 = middle)
            
        Returns:
            Dictionary with upper and lower damage percentages
        """
        
        lung_mask = np.uint8(lung_mask)
        h, w = lung_mask.shape
        
        # Split at horizontal center
        split_point = int(h * upper_threshold)
        
        upper_lung = lung_mask[:split_point, :]
        lower_lung = lung_mask[split_point:, :]
        
        # Calculate for each region
        upper_total = np.count_nonzero(upper_lung > 127)
        lower_total = np.count_nonzero(lower_lung > 127)
        
        upper_damage = (upper_total / (split_point * w) * 100) if split_point > 0 else 0
        lower_damage = (lower_total / ((h - split_point) * w) * 100) if h > split_point else 0
        
        return {
            'upper_region': upper_damage,
            'lower_region': lower_damage,
            'upper_pixels': upper_total,
            'lower_pixels': lower_total
        }
    
    def quantify_damage(self, lung_mask):
        """
        Complete damage quantification analysis
        
        Args:
            lung_mask: Binary lung segmentation mask
            
        Returns:
            Dictionary with comprehensive damage analysis
        """
        
        # Overall damage
        overall_damage, total_pixels, damaged_pixels = self.calculate_damage_percentage(lung_mask)
        
        # Lobe-wise damage
        lobe_damage = self.calculate_lobe_damage(lung_mask)
        
        # Regional damage
        regional_damage = self.calculate_upper_lower_damage(lung_mask)
        
        results = {
            'overall_damage_percentage': overall_damage,
            'total_lung_pixels': total_pixels,
            'damaged_pixels': damaged_pixels,
            'lobe_damage': lobe_damage,
            'regional_damage': regional_damage
        }
        
        return results
    
    def print_damage_report(self, damage_results, classification_result=None):
        """
        Print formatted damage report
        
        Args:
            damage_results: Results from quantify_damage()
            classification_result: TB/Normal classification result
        """
        
        print("\n" + "="*60)
        print("LUNG DAMAGE ASSESSMENT REPORT")
        print("="*60)
        
        if classification_result:
            print(f"\nClassification: {classification_result}")
        
        print(f"\nOverall Lung Damage: {damage_results['overall_damage_percentage']:.2f}%")
        print(f"  Total lung pixels: {damage_results['total_lung_pixels']}")
        print(f"  Damaged pixels: {damage_results['damaged_pixels']}")
        
        print(f"\nLobe-wise Damage:")
        print(f"  Left lobe: {damage_results['lobe_damage']['left_lobe']:.2f}%")
        print(f"  Right lobe: {damage_results['lobe_damage']['right_lobe']:.2f}%")
        
        print(f"\nRegional Damage:")
        print(f"  Upper region: {damage_results['regional_damage']['upper_region']:.2f}%")
        print(f"  Lower region: {damage_results['regional_damage']['lower_region']:.2f}%")
        
        print("\n" + "="*60 + "\n")


# Example usage
if __name__ == "__main__":
    # Initialize quantifier (without model for testing)
    quantifier = DamageQuantifier()
    
    # Create sample mask
    mask = np.zeros((224, 224), dtype=np.uint8)
    # Simulate lungs
    mask[50:200, 40:110] = 255  # Left lung
    mask[50:200, 114:184] = 255  # Right lung
    
    # Quantify damage
    results = quantifier.quantify_damage(mask)
    quantifier.print_damage_report(results, classification_result="TB Positive")
