# src/evaluation/gradcam.py

import numpy as np
import tensorflow as tf
import cv2
from PIL import Image


class GradCAM:
    """
    Grad-CAM for XceptionClassifier that wraps an internal 'xception' backbone.
    """

    def __init__(self, model, target_layer_name=None):
        """
        Args:
            model: top-level XceptionClassifier (with a layer named 'xception').
            target_layer_name: name of conv layer INSIDE backbone.xception.
                               If None, auto-detect last conv-like layer.
        """
        self.model = model
        # this is the internal Xception backbone
        self.backbone = self.model.get_layer("xception")
        self.target_layer = self._find_target_layer(target_layer_name)

    def _find_target_layer(self, name):
        # If user passes an explicit layer name, look inside backbone
        if name is not None:
            return self.backbone.get_layer(name).output

        # Otherwise search inside backbone for last conv-like layer
        for layer in reversed(self.backbone.layers):
            if isinstance(layer, (
                tf.keras.layers.Conv2D,
                tf.keras.layers.SeparableConv2D,
                tf.keras.layers.DepthwiseConv2D
            )):
                return layer.output

        raise ValueError(
            "Could not find a convolutional layer inside 'xception' for Grad-CAM. "
            "Pass target_layer_name explicitly (e.g. 'block14_sepconv2_act')."
        )

    def compute_heatmap(self, image_batch, class_index=None):
        """
        Compute Grad-CAM heatmap for one image.

        Args:
            image_batch: (1, H, W, 3) preprocessed input.
            class_index: target class index; if None, uses argmax.

        Returns:
            heatmap: 2D float array in [0,1].
        """
        # Model that outputs conv feature maps (inside backbone) + final predictions
        grad_model = tf.keras.models.Model(
            inputs=self.model.inputs,
            outputs=[self.target_layer, self.model.output]
        )

        # Use GradientTape around a forward pass
        with tf.GradientTape() as tape:
            # Ensure tape watches input
            inputs = tf.cast(image_batch, tf.float32)
            tape.watch(inputs)

            conv_outputs, preds = grad_model(inputs, training=False)

            if class_index is None:
                class_index = tf.argmax(preds[0])
            loss = preds[:, class_index]

        # Gradients of loss w.r.t conv outputs
        grads = tape.gradient(loss, conv_outputs)              # (1, H_t, W_t, C)
        pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))   # (C,)

        conv_outputs = conv_outputs[0]                         # (H_t, W_t, C)

        # Weight channels by importance
        conv_outputs = conv_outputs * pooled_grads

        # Channel-wise mean → heatmap
        heatmap = tf.reduce_mean(conv_outputs, axis=-1).numpy()  # (H_t, W_t)

        # Normalize to [0,1]
        heatmap = np.maximum(heatmap, 0)
        if heatmap.max() > 0:
            heatmap /= heatmap.max()
        else:
            heatmap = np.zeros_like(heatmap)

        return heatmap

    @staticmethod
    def resize_and_colorize(heatmap, target_size):
        w, h = target_size
        heatmap_resized = cv2.resize(heatmap, (w, h), interpolation=cv2.INTER_LINEAR)
        heatmap_uint8 = np.uint8(255 * heatmap_resized)
        colored_bgr = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)
        colored_rgb = cv2.cvtColor(colored_bgr, cv2.COLOR_BGR2RGB)
        return colored_rgb

    @staticmethod
    def overlay_on_image(original_gray, colored_heatmap, alpha=0.5):
        if original_gray.ndim == 2:
            original_rgb = cv2.cvtColor(original_gray, cv2.COLOR_GRAY2RGB)
        else:
            original_rgb = original_gray

        h, w = original_rgb.shape[:2]
        colored_heatmap = cv2.resize(colored_heatmap, (w, h), interpolation=cv2.INTER_LINEAR)

        overlay = cv2.addWeighted(original_rgb, 1 - alpha, colored_heatmap, alpha, 0)
        return overlay.astype(np.uint8)

    @staticmethod
    def apply_lung_mask(cam_rgb, lung_mask):
        h, w = cam_rgb.shape[:2]
        lung_mask_resized = cv2.resize(lung_mask, (w, h), interpolation=cv2.INTER_NEAREST)
        lung_mask_norm = (lung_mask_resized > 0).astype(np.uint8)
        lung_mask_3d = np.stack([lung_mask_norm] * 3, axis=-1)
        return (cam_rgb * lung_mask_3d).astype(np.uint8)

    @staticmethod
    def make_triplet_grid(original_gray, full_cam_overlay, masked_cam_overlay):
        if original_gray.ndim == 2:
            orig_rgb = cv2.cvtColor(original_gray, cv2.COLOR_GRAY2RGB)
        else:
            orig_rgb = original_gray

        h, w = orig_rgb.shape[:2]
        full_cam_overlay = cv2.resize(full_cam_overlay, (w, h), interpolation=cv2.INTER_LINEAR)
        masked_cam_overlay = cv2.resize(masked_cam_overlay, (w, h), interpolation=cv2.INTER_LINEAR)

        grid = np.zeros((h, w * 3, 3), dtype=np.uint8)
        grid[:, :w] = orig_rgb
        grid[:, w:2 * w] = full_cam_overlay
        grid[:, 2 * w:] = masked_cam_overlay

        return Image.fromarray(grid)
