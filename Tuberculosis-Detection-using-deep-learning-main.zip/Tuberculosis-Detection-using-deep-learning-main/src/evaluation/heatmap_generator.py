# src/evaluation/heatmap_generator.py

import numpy as np
import cv2
from pathlib import Path
from PIL import Image, ImageDraw


class HeatmapGenerator:
    """
    Generate synthetic red 'damage blobs' based on:
      - lung mask (allowed region),
      - damage percentages per lobe and region (from DamageQuantifier).

    For each quadrant (LU, LL, RU, RL):
      - Create one irregular blob inside that region.
      - Blob area ~ target percentage of that region's lung area.
      - Color = red only, background = black.
    """

    def __init__(self):
        pass

    # ---------- region helpers ----------

    @staticmethod
    def _split_lung_regions(lung_mask: np.ndarray):
        """
        Split lung mask into four boolean masks:
          left_upper, left_lower, right_upper, right_lower.
        """
        h, w = lung_mask.shape
        mid_x = w // 2
        mid_y = h // 2

        lung_bin = lung_mask > 0

        left = np.zeros_like(lung_bin, dtype=bool)
        right = np.zeros_like(lung_bin, dtype=bool)
        left[:, :mid_x] = True
        right[:, mid_x:] = True

        upper = np.zeros_like(lung_bin, dtype=bool)
        lower = np.zeros_like(lung_bin, dtype=bool)
        upper[:mid_y, :] = True
        lower[mid_y:, :] = True

        left_upper = lung_bin & left & upper
        left_lower = lung_bin & left & lower
        right_upper = lung_bin & right & upper
        right_lower = lung_bin & right & lower

        return left_upper, left_lower, right_upper, right_lower

    # ---------- blob generator ----------

    @staticmethod
    def _single_blob_in_region(region_mask: np.ndarray,
                               target_percent: float,
                               rng: np.random.Generator) -> np.ndarray:
        """
        Create one contiguous-ish blob inside region_mask.

        Strategy:
          - If target_percent is small, blob will be small.
          - Make a Gaussian bump around a random center, then
            keep top-K pixels so area ≈ target_percent of region.
        """
        coords = np.column_stack(np.where(region_mask))
        n_pixels = len(coords)
        if n_pixels == 0 or target_percent <= 0:
            return np.zeros_like(region_mask, dtype=bool)

        frac = np.clip(target_percent / 100.0, 0.0, 1.0)
        n_target = int(round(frac * n_pixels))
        if n_target <= 0:
            return np.zeros_like(region_mask, dtype=bool)
        if n_target > n_pixels:
            n_target = n_pixels

        # pick random center inside region
        cy, cx = coords[rng.integers(0, n_pixels)]

        # distance-based score around center (Gaussian-like)
        yy, xx = np.indices(region_mask.shape)
        dist2 = (yy - cy) ** 2 + (xx - cx) ** 2

        # random eccentricity to break perfect circles
        kx = rng.uniform(0.5, 1.5)
        ky = rng.uniform(0.5, 1.5)
        dist2 = ((yy - cy) ** 2) * ky + ((xx - cx) ** 2) * kx

        # convert to "intensity": higher near center
        sigma2 = max(region_mask.shape) ** 2 / 16.0
        scores = np.exp(-dist2 / (2.0 * sigma2))

        # only consider pixels actually in region
        scores[~region_mask] = 0.0

        flat_scores = scores.flatten()
        idx_sorted = np.argsort(flat_scores)[::-1]  # descending
        idx_keep = idx_sorted[:n_target]

        blob = np.zeros_like(region_mask, dtype=bool)
        blob[np.unravel_index(idx_keep, region_mask.shape)] = True
        return blob

    # ---------- damage map synthesis ----------

    def create_blob_damage_map(self, lung_mask: np.ndarray,
                               damage_results: dict,
                               seed: int = 42) -> np.ndarray:
        """
        Build a 2D damage map with one red blob per quadrant.

        Returns:
            damage_map: 2D float [0,1], 1.0 where damaged.
        """
        h, w = lung_mask.shape
        damage_map = np.zeros((h, w), dtype=np.float32)

        left_upper, left_lower, right_upper, right_lower = self._split_lung_regions(lung_mask)

        lobe = damage_results.get("lobe_damage", {})
        region = damage_results.get("regional_damage", {})
        overall = float(damage_results.get("overall_damage_percentage", 0.0))

        left_lobe_pct = float(lobe.get("left_lobe", overall))
        right_lobe_pct = float(lobe.get("right_lobe", overall))
        upper_pct = float(region.get("upper_region", overall))
        lower_pct = float(region.get("lower_region", overall))

        rng = np.random.default_rng(seed)

        def local_percent(is_left: bool, is_upper: bool) -> float:
            p_lobe = left_lobe_pct if is_left else right_lobe_pct
            p_vert = upper_pct if is_upper else lower_pct
            # average keeps consistency but avoids huge fill
            return (p_lobe + p_vert) / 2.0

        lu_blob = self._single_blob_in_region(left_upper,  local_percent(True, True),  rng)
        ll_blob = self._single_blob_in_region(left_lower,  local_percent(True, False), rng)
        ru_blob = self._single_blob_in_region(right_upper, local_percent(False, True), rng)
        rl_blob = self._single_blob_in_region(right_lower, local_percent(False, False), rng)

        damage_map[lu_blob] = 1.0
        damage_map[ll_blob] = 1.0
        damage_map[ru_blob] = 1.0
        damage_map[rl_blob] = 1.0

        return damage_map

    # ---------- coloring & overlays ----------

    def create_red_heatmap(self, lung_mask: np.ndarray,
                           damage_map: np.ndarray) -> np.ndarray:
        """
        Produce pure red map: red where damaged, black elsewhere,
        strictly inside lung_mask.
        """
        h, w = lung_mask.shape
        if damage_map.shape != (h, w):
            damage_map = cv2.resize(damage_map.astype(np.float32),
                                    (w, h), interpolation=cv2.INTER_LINEAR)

        lung_bin = (lung_mask > 0).astype(np.uint8)
        dmg_bin = (damage_map > 0).astype(np.uint8) * lung_bin

        # red channel = 255 where damaged, else 0
        red = (dmg_bin * 255).astype(np.uint8)
        zero = np.zeros_like(red, dtype=np.uint8)
        heatmap_rgb = np.stack([zero, zero, red], axis=-1)  # BGR? use RGB: (R,G,B) = (red,0,0)

        # If you prefer OpenCV's BGR, swap order:
        # heatmap_bgr = np.stack([zero, zero, red], axis=-1)

        return heatmap_rgb

    def create_overlay(self, original_image: np.ndarray,
                       heatmap: np.ndarray,
                       alpha: float = 0.5) -> np.ndarray:
        """
        Blend original grayscale X-ray with red heatmap.
        """
        if original_image.ndim == 2:
            orig_rgb = cv2.cvtColor(original_image, cv2.COLOR_GRAY2BGR)
        else:
            orig_rgb = original_image.astype(np.uint8)

        h, w = orig_rgb.shape[:2]
        heatmap = cv2.resize(heatmap, (w, h), interpolation=cv2.INTER_LINEAR)

        overlay = cv2.addWeighted(orig_rgb, 1 - alpha, heatmap, alpha, 0)
        return overlay.astype(np.uint8)

    def create_labeled_heatmap(self, lung_mask: np.ndarray,
                               damage_results: dict) -> Image.Image:
        """
        Red background proportional to overall damage, + text labels.
        """
        h, w = lung_mask.shape
        overall = float(damage_results.get("overall_damage_percentage", 0.0))
        lobe = damage_results.get("lobe_damage", {})
        region = damage_results.get("regional_damage", {})

        # flat damage proportional to overall % just for background tint
        dmg_flat = np.full((h, w), overall / 100.0, dtype=np.float32)
        base_red = self.create_red_heatmap(lung_mask, dmg_flat)
        img = Image.fromarray(base_red, mode="RGB")
        draw = ImageDraw.Draw(img)

        lines = [
            f"Overall: {overall:.1f}%",
            f"Left lobe: {float(lobe.get('left_lobe', 0.0)):.1f}%",
            f"Right lobe: {float(lobe.get('right_lobe', 0.0)):.1f}%",
            f"Upper region: {float(region.get('upper_region', 0.0)):.1f}%",
            f"Lower region: {float(region.get('lower_region', 0.0)):.1f}%",
        ]
        y = 10
        for text in lines:
            draw.text((10, y), text, fill=(255, 255, 255))
            y += 18

        return img

    # ---------- save all views ----------

    def save_visualization(self, image: np.ndarray, lung_mask: np.ndarray,
                           damage_results: dict, output_base,
                           create_comparison: bool = True):
        """
        Full pipeline:
          - build blob damage_map from percentages,
          - create red-only heatmap, overlay, labeled, comparison.
        """
        output_base = Path(output_base)
        output_dir = output_base.parent
        output_dir.mkdir(parents=True, exist_ok=True)

        damage_map = self.create_blob_damage_map(lung_mask, damage_results)

        # Heatmap (red only)
        heatmap_rgb = self.create_red_heatmap(lung_mask, damage_map)
        Image.fromarray(heatmap_rgb).save(f"{output_base}_heatmap.png")

        # Overlay
        overlay = self.create_overlay(image, heatmap_rgb, alpha=0.6)
        Image.fromarray(overlay).save(f"{output_base}_overlay.png")

        # Labeled
        labeled = self.create_labeled_heatmap(lung_mask, damage_results)
        labeled.save(f"{output_base}_labeled.png")

        # Comparison
        if create_comparison:
            comp = self._create_comparison_grid(image, heatmap_rgb, overlay, lung_mask)
            comp.save(f"{output_base}_comparison.png")

        print(f"  ✓ Visualizations saved under {output_dir}")

    def _create_comparison_grid(self, original, heatmap, overlay, lung_mask):
        """
        2x2 grid: original | heatmap / overlay | mask.
        """
        if original.ndim == 2:
            orig_rgb = cv2.cvtColor(original, cv2.COLOR_GRAY2BGR)
        else:
            orig_rgb = original

        h, w = orig_rgb.shape[:2]
        heatmap = cv2.resize(heatmap, (w, h), interpolation=cv2.INTER_LINEAR)
        overlay = cv2.resize(overlay, (w, h), interpolation=cv2.INTER_LINEAR)
        mask_resized = cv2.resize(lung_mask.astype(np.uint8), (w, h),
                                  interpolation=cv2.INTER_NEAREST)
        mask_rgb = np.stack([mask_resized] * 3, axis=-1)

        grid = np.zeros((h * 2, w * 2, 3), dtype=np.uint8)
        grid[:h, :w] = orig_rgb
        grid[:h, w:] = heatmap
        grid[h:, :w] = overlay
        grid[h:, w:] = mask_rgb

        return Image.fromarray(grid)
