import tensorflow as tf
from tensorflow.keras.applications import Xception
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout


def build_xception(input_shape=(224, 224, 3), num_classes=2, dropout_rate=0.25):
    """
    Build Xception classification model (per Sharma et al. 2024)
    
    Architecture:
    - Base: Pre-trained Xception (ImageNet)
    - Entry flow: Initial convolutions
    - Middle flow: 18×18×728 feature maps
    - Exit flow: Final classification
    - Custom top: Dense layers + Softmax
    
    Loss: Categorical Crossentropy
    Optimizer: Adam (lr=0.001)
    """

    # Load pre-trained Xception backbone
    base_model = Xception(
        weights='imagenet',
        include_top=False,
        input_shape=input_shape
    )

    # Freeze the base model for transfer learning
    base_model.trainable = False

    # Custom classifier head
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(2048, activation='relu')(x)
    x = Dropout(dropout_rate)(x)
    outputs = Dense(num_classes, activation='softmax')(x)

    # Build the final model
    model = Model(inputs=base_model.input, outputs=outputs)

    return model
