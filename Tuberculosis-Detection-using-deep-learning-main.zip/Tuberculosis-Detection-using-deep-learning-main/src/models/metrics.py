import numpy as np
from sklearn.metrics import (
    confusion_matrix,
    precision_score,
    recall_score,
    f1_score,
    roc_curve,
    auc,
    classification_report
)


class EvaluationMetrics:
    """Compute evaluation metrics per Sharma et al. 2024"""

    @staticmethod
    def compute_segmentation_metrics(y_true, y_pred):
        """Compute metrics for segmentation"""
        y_pred_binary = (y_pred > 0.5).astype(np.float32)

        # Accuracy
        accuracy = np.sum(y_true == y_pred_binary) / y_true.size

        # Dice coefficient
        intersection = np.sum(y_true * y_pred_binary)
        dice = (2 * intersection) / (np.sum(y_true) + np.sum(y_pred_binary) + 1e-7)

        # Jaccard index (IoU)
        jaccard = intersection / (
            np.sum(y_true) + np.sum(y_pred_binary) - intersection + 1e-7
        )

        return {'accuracy': accuracy, 'dice': dice, 'jaccard': jaccard}

    @staticmethod
    def compute_classification_metrics(y_true, y_pred_probs):
        """Compute metrics for classification"""
        y_pred = np.argmax(y_pred_probs, axis=1)

        accuracy = np.mean(y_true == y_pred)
        precision = precision_score(y_true, y_pred, average='weighted')
        recall = recall_score(y_true, y_pred, average='weighted')
        f1 = f1_score(y_true, y_pred, average='weighted')

        # AUC
        fpr, tpr, _ = roc_curve(y_true, y_pred_probs[:, 1])
        auc_score = auc(fpr, tpr)

        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'auc': auc_score,
            'confusion_matrix': confusion_matrix(y_true, y_pred)
        }
