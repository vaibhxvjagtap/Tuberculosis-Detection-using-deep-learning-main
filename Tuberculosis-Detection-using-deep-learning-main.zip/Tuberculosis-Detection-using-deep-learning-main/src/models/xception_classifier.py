# src/models/xception_classifier.py
"""
Xception Classification Model for TB Detection
Binary/Multi-class classification: Healthy vs Sick Non-TB vs TB
"""

import tensorflow as tf
from tensorflow.keras import layers, Model
from tensorflow.keras.applications import Xception
from tensorflow.keras.optimizers import Adam


def build_xception_classifier(num_classes=3, input_shape=(224, 224, 3), 
                             use_pretrained=True, dropout_rate=0.5):
    """
    Build Xception classification model
    
    Args:
        num_classes: Number of classes (3 for Healthy/Sick/TB)
        input_shape: Input image shape
        use_pretrained: Use ImageNet pretrained weights
        dropout_rate: Dropout rate for regularization
        
    Returns:
        Compiled Keras model
    """
    
    # Load base Xception model
    if use_pretrained:
        base_model = Xception(
            weights='imagenet',
            include_top=False,
            input_shape=input_shape
        )
        print("✓ Loaded Xception with ImageNet pretrained weights")
    else:
        base_model = Xception(
            weights=None,
            include_top=False,
            input_shape=input_shape
        )
        print("✓ Loaded Xception trained from scratch")
    
    # Freeze base model layers
    base_model.trainable = False
    
    # Build model
    inputs = layers.Input(shape=input_shape)
    
    # Apply base model
    x = base_model(inputs, training=False)
    
    # Global average pooling
    x = layers.GlobalAveragePooling2D()(x)
    
    # Dense layers with regularization
    x = layers.Dense(512, activation='relu', 
                    kernel_regularizer=tf.keras.regularizers.l2(0.001))(x)
    x = layers.Dropout(dropout_rate)(x)
    
    x = layers.Dense(256, activation='relu',
                    kernel_regularizer=tf.keras.regularizers.l2(0.001))(x)
    x = layers.Dropout(dropout_rate)(x)
    
    x = layers.Dense(128, activation='relu',
                    kernel_regularizer=tf.keras.regularizers.l2(0.001))(x)
    x = layers.Dropout(dropout_rate/2)(x)
    
    # Output layer
    if num_classes == 2:
        outputs = layers.Dense(1, activation='sigmoid', name='classification')(x)
    else:
        outputs = layers.Dense(num_classes, activation='softmax', name='classification')(x)
    
    # Create model
    model = Model(inputs=inputs, outputs=outputs, name='XceptionClassifier')
    
    return model, base_model


def compile_model(model, num_classes=3, learning_rate=0.001):
    """
    Compile classification model
    
    Args:
        model: Keras model
        num_classes: Number of classes
        learning_rate: Learning rate for optimizer
    """
    
    if num_classes == 2:
        loss = 'binary_crossentropy'
        metrics = ['accuracy', 
                  tf.keras.metrics.Precision(),
                  tf.keras.metrics.Recall(),
                  tf.keras.metrics.AUC()]
    else:
        loss = 'categorical_crossentropy'
        metrics = ['accuracy',
                  tf.keras.metrics.Precision(),
                  tf.keras.metrics.Recall(),
                  tf.keras.metrics.AUC()]
    
    optimizer = Adam(learning_rate=learning_rate)
    
    model.compile(
        optimizer=optimizer,
        loss=loss,
        metrics=metrics
    )
    
    print(f"\n✓ Model compiled")
    print(f"  Loss: {loss}")
    print(f"  Learning rate: {learning_rate}")
    
    return model


def unfreeze_base_model(model, num_layers_to_unfreeze=50):
    """
    Unfreeze some layers of base model for fine-tuning
    
    Args:
        model: Keras model
        num_layers_to_unfreeze: Number of layers to unfreeze from end
    """
    
    base_model = model.layers[1]  # Get base model
    
    # Unfreeze last num_layers_to_unfreeze layers
    for layer in base_model.layers[-num_layers_to_unfreeze:]:
        layer.trainable = True
    
    # Lower learning rate for fine-tuning
    for layer in base_model.layers[-num_layers_to_unfreeze:]:
        if hasattr(layer, 'kernel_regularizer'):
            print(f"Unfreezing layer: {layer.name}")
    
    print(f"\n✓ Unfroze last {num_layers_to_unfreeze} layers of base model for fine-tuning")
    
    return model


# Example usage
if __name__ == "__main__":
    # Build model
    model, base_model = build_xception_classifier(
        num_classes=3,
        input_shape=(224, 224, 3),
        use_pretrained=True,
        dropout_rate=0.5
    )
    
    # Compile
    model = compile_model(model, num_classes=3, learning_rate=0.001)
    
    # Print model summary
    model.summary()
