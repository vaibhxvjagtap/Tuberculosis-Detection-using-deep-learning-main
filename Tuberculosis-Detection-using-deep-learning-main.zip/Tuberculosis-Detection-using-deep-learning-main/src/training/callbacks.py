import tensorflow as tf
from pathlib import Path
from datetime import datetime


class LoggingCallback(tf.keras.callbacks.Callback):
    """Custom callback to log metrics per epoch"""

    def __init__(self, log_dir, fold=None):
        super().__init__()
        self.log_dir = Path(log_dir)
        self.fold = fold
        self.log_dir.mkdir(parents=True, exist_ok=True)

    def on_epoch_end(self, epoch, logs=None):
        if logs is None:
            return

        epoch_num = epoch + 1

        if self.fold:
            filename = f"train_fold{self.fold}_epoch{epoch_num:03d}_metrics.txt"
        else:
            filename = f"train_epoch{epoch_num:03d}_metrics.txt"

        filepath = self.log_dir / filename

        with open(filepath, 'w') as f:
            f.write(f"Epoch: {epoch_num}\n")
            f.write(f"Timestamp: {datetime.now()}\n")
            f.write("=" * 60 + "\n\n")

            for key, value in logs.items():
                f.write(f"{key:<40} {float(value):.6f}\n")
