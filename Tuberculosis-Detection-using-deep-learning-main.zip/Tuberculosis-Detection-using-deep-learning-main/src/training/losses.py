import tensorflow as tf
from tensorflow.keras import backend as K

def dice_coefficient(y_true, y_pred, smooth=1.0):
    y_pred = tf.cast(y_pred > 0.5, tf.float32)
    intersection = K.sum(y_true * y_pred)
    dice = (2.0 * intersection + smooth) / (K.sum(y_true) + K.sum(y_pred) + smooth)
    return dice

def jaccard_index(y_true, y_pred, smooth=1.0):
    y_pred = tf.cast(y_pred > 0.5, tf.float32)
    intersection = K.sum(y_true * y_pred)
    union = K.sum(y_true) + K.sum(y_pred) - intersection
    jaccard = (intersection + smooth) / (union + smooth)
    return jaccard

def sensitivity(y_true, y_pred):
    tp = K.sum(K.round(y_pred * y_true))
    possible_positives = K.sum(y_true)
    return tp / (possible_positives + K.epsilon())

def specificity(y_true, y_pred):
    tn = K.sum(K.round((1 - y_pred) * (1 - y_true)))
    possible_negatives = K.sum(1 - y_true)
    return tn / (possible_negatives + K.epsilon())

def precision_metric(y_true, y_pred):
    tp = K.sum(K.round(y_pred * y_true))
    fp = K.sum(K.round(y_pred * (1 - y_true)))
    return tp / (tp + fp + K.epsilon())

