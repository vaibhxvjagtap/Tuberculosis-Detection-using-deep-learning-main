# src/training/train_classification.py
"""
Xception Classification Model Training for TBX11K Dataset
Trains on 3000 balanced images: Healthy vs Sick Non-TB vs Active TB
"""

import os
import sys
import numpy as np
from pathlib import Path
import tensorflow as tf
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import (
    ModelCheckpoint, EarlyStopping, ReduceLROnPlateau, TensorBoard
)
import json
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.data.tbx11k_loader import TBX11KClassificationLoader
from src.models.xception_classifier import build_xception_classifier, compile_model, unfreeze_base_model
# from src.config import *  # NOT NEEDED



class ClassificationTrainer:
    """
    Train Xception classification model on TBX11K dataset
    """
    
    def __init__(self, config=None):
        """
        Initialize trainer
        
        Args:
            config: Configuration dictionary
        """
        self.config = config or {}
        self.results_dir = Path(self.config.get('results_dir', 'results/classification'))
        self.models_dir = Path(self.config.get('models_dir', 'models/xception_classification'))
        
        # Create directories
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        
        self.training_history = {}
    
    # ===== COMMENTED OUT: SKIP TRAINING =====
    # def train(self, X_train, y_train, X_val, y_val, 
    #           num_classes=3, epochs=50, batch_size=16):
    #     """
    #     Train classification model
    #     
    #     Args:
    #         X_train: Training images
    #         y_train: Training labels
    #         X_val: Validation images
    #         y_val: Validation labels
    #         num_classes: Number of classes
    #         epochs: Number of epochs
    #         batch_size: Batch size
    #     """
    #     
    #     print("\n" + "="*80)
    #     print("TRAINING XCEPTION CLASSIFICATION MODEL - TBX11K DATASET")
    #     print("="*80 + "\n")
    #     
    #     print(f"Training set: {len(X_train)} images")
    #     print(f"Validation set: {len(X_val)} images")
    #     print(f"Classes: {num_classes}")
    #     print(f"Epochs: {epochs}")
    #     print(f"Batch size: {batch_size}\n")
    #     
    #     # GPU Check
    #     gpus = tf.config.list_physical_devices('GPU')
    #     print(f"GPUs available: {len(gpus)}")
    #     if gpus:
    #         print(f"Using GPU: {gpus[0].name}\n")
    #     else:
    #         print("Training on CPU\n")
    #     
    #     # Build model
    #     print("[1/4] Building Xception model...")
    #     model, base_model = build_xception_classifier(
    #         num_classes=num_classes,
    #         input_shape=(224, 224, 3),
    #         use_pretrained=True,
    #         dropout_rate=0.5
    #     )
    #     
    #     # Compile
    #     print("\n[2/4] Compiling model...")
    #     model = compile_model(model, num_classes=num_classes, learning_rate=0.001)
    #     
    #     # Convert labels to one-hot
    #     if num_classes > 2:
    #         y_train_encoded = tf.keras.utils.to_categorical(y_train, num_classes)
    #         y_val_encoded = tf.keras.utils.to_categorical(y_val, num_classes)
    #     else:
    #         y_train_encoded = y_train
    #         y_val_encoded = y_val
    #     
    #     # Callbacks
    #     print("\n[3/4] Setting up callbacks...")
    #     
    #     checkpoint = ModelCheckpoint(
    #         str(self.models_dir / 'xception_best.h5'),
    #         save_best_only=True,
    #         monitor='val_accuracy',
    #         verbose=1,
    #         mode='max'
    #     )
    #     
    #     early_stop = EarlyStopping(
    #         monitor='val_accuracy',
    #         patience=15,
    #         verbose=1,
    #         restore_best_weights=True,
    #         mode='max'
    #     )
    #     
    #     reduce_lr = ReduceLROnPlateau(
    #         monitor='val_loss',
    #         factor=0.5,
    #         patience=5,
    #         verbose=1,
    #         min_lr=1e-7
    #     )
    #     
    #     tensorboard = TensorBoard(
    #         log_dir=str(self.results_dir / 'logs'),
    #         histogram_freq=0,
    #         write_graph=True,
    #         update_freq='epoch'
    #     )
    #     
    #     # Train
    #     print(f"\n[4/4] Training model for {epochs} epochs...\n")
    #     history = model.fit(
    #         X_train, y_train_encoded,
    #         validation_data=(X_val, y_val_encoded),
    #         epochs=epochs,
    #         batch_size=batch_size,
    #         callbacks=[checkpoint, early_stop, reduce_lr, tensorboard],
    #         verbose=1
    #     )
    #     
    #     self.training_history = history.history
    #     
    #     # Fine-tuning (optional)
    #     print("\n" + "="*80)
    #     print("FINE-TUNING: Unfreezing base model layers...")
    #     print("="*80 + "\n")
    #     
    #     model = unfreeze_base_model(model, num_layers_to_unfreeze=50)
    #     model = compile_model(model, num_classes=num_classes, learning_rate=0.0001)
    #     
    #     # Train with unfrozen layers
    #     print(f"Fine-tuning for {epochs//2} epochs...\n")
    #     history_ft = model.fit(
    #         X_train, y_train_encoded,
    #         validation_data=(X_val, y_val_encoded),
    #         epochs=epochs//2,
    #         batch_size=batch_size,
    #         callbacks=[checkpoint, early_stop, reduce_lr],
    #         verbose=1
    #     )
    #     
    #     # Safely merge histories
    #     self.training_history = history.history
    #     for key, values in history_ft.history.items():
    #         if key in self.training_history:
    #             self.training_history[key].extend(values)
    #         else:
    #             self.training_history[key] = values
    #     
    #     # Save final model
    #     print(f"\n✓ Saving final model...")
    #     model.save(str(self.models_dir / 'xception_final.h5'))
    #     
    #     # Save training history
    #     with open(self.results_dir / 'training_history.json', 'w') as f:
    #         json.dump(self.training_history, f, indent=4)
    #     
    #     print("✓ Training complete!")
    #     
    #     return model
    # ===== END COMMENTED TRAINING =====
    
    
    def evaluate(self, model, X_test, y_test, num_classes=3):
        """
        Evaluate model on test set
        
        Args:
            model: Trained model
            X_test: Test images
            y_test: Test labels
            num_classes: Number of classes
            
        Returns:
            Test results dictionary
        """
        
        print("\n" + "="*80)
        print("EVALUATING MODEL ON TEST SET")
        print("="*80 + "\n")
        
        # Convert labels
        if num_classes > 2:
            y_test_encoded = tf.keras.utils.to_categorical(y_test, num_classes)
        else:
            y_test_encoded = y_test
        
        # Evaluate
        results = model.evaluate(X_test, y_test_encoded, verbose=0)
        
        # Get predictions
        predictions = model.predict(X_test, verbose=0)
        
        if num_classes > 2:
            pred_classes = np.argmax(predictions, axis=1)
        else:
            pred_classes = (predictions > 0.5).astype(int).flatten()
        
        # Compute metrics
        from sklearn.metrics import (
            accuracy_score, precision_score, recall_score, f1_score, 
            roc_auc_score, confusion_matrix, classification_report
        )
        
        accuracy = accuracy_score(y_test, pred_classes)
        precision = precision_score(y_test, pred_classes, average='weighted', zero_division=0)
        recall = recall_score(y_test, pred_classes, average='weighted', zero_division=0)
        f1 = f1_score(y_test, pred_classes, average='weighted', zero_division=0)
        
        try:
            if num_classes == 2:
                auc = roc_auc_score(y_test, predictions)
            else:
                auc = roc_auc_score(y_test, predictions, multi_class='ovr', average='weighted')
        except:
            auc = 0.0
        
        # Confusion matrix
        cm = confusion_matrix(y_test, pred_classes)
        
        # Print results
        print("Test Results:")
        print(f"  Accuracy:  {accuracy:.4f}")
        print(f"  Precision: {precision:.4f}")
        print(f"  Recall:    {recall:.4f}")
        print(f"  F1-Score:  {f1:.4f}")
        print(f"  AUC:       {auc:.4f}\n")
        
        print("Confusion Matrix:")
        print(cm)
        print()
        
        print("Classification Report:")
        print(classification_report(y_test, pred_classes))
        
        # Save results
        test_results = {
            'accuracy': float(accuracy),
            'precision': float(precision),
            'recall': float(recall),
            'f1_score': float(f1),
            'auc': float(auc),
            'confusion_matrix': cm.tolist(),
            'timestamp': datetime.now().isoformat()
        }
        
        with open(self.results_dir / 'test_results.json', 'w') as f:
            json.dump(test_results, f, indent=4)
        
        print("\n✓ Test results saved to:", self.results_dir / 'test_results.json')
        
        return test_results



def main():
    """
    Main evaluation pipeline (SKIPS TRAINING)
    """
    
    # Configuration
    TBX11K_ROOT = r"D:\College\sem5\AI\Project\TB11k\TBX11k"
    N_SAMPLES_PER_CLASS = 1000
    # EPOCHS = 50  # NOT NEEDED - skipping training
    # BATCH_SIZE = 16  # NOT NEEDED - skipping training
    
    print("\n" + "="*80)
    print("TB DETECTION - EVALUATE EXISTING MODEL")
    print("Dataset: TBX11K (3000 balanced images)")
    print("="*80 + "\n")
    
    # Load data
    print("[1/4] Loading TBX11K dataset...")
    loader = TBX11KClassificationLoader(tbx11k_root_path=TBX11K_ROOT)
    images, labels, names = loader.create_balanced_dataset(
        n_samples_per_class=N_SAMPLES_PER_CLASS
    )
    
    # Create splits
    print("\n[2/4] Creating train/val/test split...")
    X_train, X_val, X_test, y_train, y_val, y_test = loader.get_train_val_test_split(
        images, labels,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15
    )
    
    # Initialize trainer
    trainer = ClassificationTrainer()
    
    # ===== SKIP TRAINING - COMMENTED OUT =====
    # print("\n[3/4] Training model...")
    # model = trainer.train(
    #     X_train, y_train,
    #     X_val, y_val,
    #     num_classes=3,
    #     epochs=EPOCHS,
    #     batch_size=BATCH_SIZE
    # )
    # ===== END SKIP TRAINING =====
    
    # Load existing trained model
    print("\n[3/4] Loading existing trained model...")
    model_path = trainer.models_dir / 'xception_best.h5'
    if not model_path.exists():
        print(f"✗ Model not found at {model_path}")
        print("  Make sure you have trained the model first!")
        return
    
    model = tf.keras.models.load_model(str(model_path))
    print(f"✓ Model loaded from: {model_path}")
    
    # Evaluate
    print("\n[4/4] Evaluating on test set...")
    test_results = trainer.evaluate(model, X_test, y_test, num_classes=3)
    
    print("\n" + "="*80)
    print("✅ EVALUATION COMPLETE!")
    print("="*80)
    print(f"\n✓ Results saved to: {trainer.results_dir / 'test_results.json'}\n")



if __name__ == "__main__":
    main()
