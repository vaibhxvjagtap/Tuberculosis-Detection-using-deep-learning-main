import os
import numpy as np
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import tensorflow as tf
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping

from src.config import *
from src.data.data_loader import SegmentationDataLoader
from src.models.unet import build_unet
from src.training.losses import dice_coefficient, jaccard_index
from src.training.callbacks import LoggingCallback
from src.utils.result_logger import ResultLogger


def train_unet_5fold():
    """
    Train UNet with 5-fold cross-validation (per Sharma et al. 2024)
    
    Data: 704 images from Montgomery + Shenzhen
    Split: 70% train, 20% val, 10% test per fold
    Epochs: 100
    Batch size: 4
    Loss: Binary Crossentropy
    Learning rate: 0.001
    Dropout: 0.25
    """
    print("\n" + "=" * 80)
    print("TRAINING UNET SEGMENTATION MODEL - 5-FOLD CROSS-VALIDATION")
    print("=" * 80 + "\n")

    # GPU Check
    print("GPU Check:")
    print(f"Num GPUs: {len(tf.config.list_physical_devices('GPU'))}\n")

    # Setup directories
    results_dir = RESULTS_DIR / 'segmentation' / 'training_logs'
    results_dir.mkdir(parents=True, exist_ok=True)

    models_dir = MODELS_DIR / 'unet_segmentation'
    models_dir.mkdir(parents=True, exist_ok=True)

    logger = ResultLogger(str(results_dir))

    # Load data
    print("[1/5] Loading data (704 images)...")
    loader = SegmentationDataLoader()
    images, masks = loader.load_data()
    print(f"✓ Loaded {len(images)} image-mask pairs\n")

    # Create 5-fold splits
    print("[2/5] Creating 5-fold cross-validation...")
    splits = loader.get_kfold_splits(images, masks, n_splits=5)
    print(f"✓ Created {len(splits)} folds\n")

    all_fold_results = []

    for fold, (train_idx, val_idx) in enumerate(splits, 1):
        print("\n" + "=" * 80)
        print(f"FOLD {fold}/5 - Training UNet")
        print("=" * 80 + "\n")

        # Split data (70% train, 20% val, 10% test)
        X_train, X_val = images[train_idx], images[val_idx]
        y_train, y_val = masks[train_idx], masks[val_idx]

        split_point = int(len(X_train) * 0.7)
        X_train_final = X_train[:split_point]
        y_train_final = y_train[:split_point]
        X_test = X_train[split_point:]
        y_test = y_train[split_point:]

        print("Data split:")
        print(f"  Train: {len(X_train_final)} images (70%)")
        print(f"  Val:   {len(X_val)} images (20%)")
        print(f"  Test:  {len(X_test)} images (10%)\n")

        # Build model
        print("Building UNet model...")
        model = build_unet(
            input_shape=UNET_CONFIG['input_shape'],
            dropout_rate=UNET_CONFIG['dropout']
        )

        model.compile(
            optimizer=Adam(learning_rate=UNET_CONFIG['learning_rate']),
            loss=UNET_CONFIG['loss'],
            metrics=['accuracy', dice_coefficient, jaccard_index]
        )
        print("✓ Model compiled\n")

        # Callbacks
        checkpoint = ModelCheckpoint(
            str(models_dir / f'unet_fold{fold}_best.h5'),
            save_best_only=True,
            monitor='val_accuracy',
            verbose=0
        )

        early_stop = EarlyStopping(
            monitor='val_accuracy',
            patience=20,
            verbose=0,
            restore_best_weights=True
        )

        logging_callback = LoggingCallback(
            log_dir=str(results_dir),
            fold=fold
        )

        # Train
        print(f"Training fold {fold} for {UNET_CONFIG['epochs']} epochs...\n")
        history = model.fit(
            X_train_final, y_train_final,
            validation_data=(X_val, y_val),
            epochs=UNET_CONFIG['epochs'],
            batch_size=UNET_CONFIG['batch_size'],
            callbacks=[checkpoint, early_stop, logging_callback],
            verbose=1
        )

        # Test
        print(f"\nEvaluating fold {fold} on test set...")
        test_results = model.evaluate(X_test, y_test, verbose=0)
        test_metrics = {
            'loss': test_results[0],
            'accuracy': test_results[1],
            'dice': test_results[2],
            'jaccard': test_results[3]
        }

        logger.log_test_results(test_metrics, fold=fold)
        all_fold_results.append(test_metrics)

        print(f"Test Results - Fold {fold}:")
        for key, value in test_metrics.items():
            print(f"  {key:<30} {value:.4f}")

        # Save model
        model.save(str(models_dir / f'unet_fold{fold}.h5'))
        print(f"✓ Saved model for fold {fold}\n")

    # Summary
    print("\n" + "=" * 80)
    print("SEGMENTATION TRAINING COMPLETE - SUMMARY")
    print("=" * 80 + "\n")

    print("Average Test Results (5-fold):\n")
    for metric in all_fold_results[0].keys():
        values = [fold[metric] for fold in all_fold_results]
        avg = np.mean(values)
        std = np.std(values)
        print(f"  {metric:<30} {avg:.4f} ± {std:.4f}")

    print("\n" + "=" * 80)
    print("✅ UNet training complete!")
    print("=" * 80 + "\n")

    # Save summary file
    summary_file = RESULTS_DIR / 'segmentation' / 'summary.txt'
    with open(summary_file, 'w') as f:
        f.write("UNet Segmentation Training Summary\n")
        f.write("=" * 60 + "\n\n")
        f.write("Expected Results (from Sharma et al. 2024):\n")
        f.write("  Accuracy: 96.35%\n")
        f.write("  Jaccard: 90.38%\n")
        f.write("  Dice: 94.88%\n")
        f.write("  AUC: 0.99\n\n")
        f.write("Your Results:\n")
        for metric in all_fold_results[0].keys():
            values = [fold[metric] for fold in all_fold_results]
            avg = np.mean(values)
            std = np.std(values)
            f.write(f"{metric}: {avg:.4f} ± {std:.4f}\n")


if __name__ == "__main__":
    train_unet_5fold()
