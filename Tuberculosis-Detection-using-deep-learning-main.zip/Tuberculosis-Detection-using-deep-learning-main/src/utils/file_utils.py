import os
import json
import pickle
import numpy as np
from pathlib import Path


class FileManager:
    """Manage file operations"""

    def __init__(self, base_dir):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def create_directory(self, *args):
        """Create a directory hierarchy"""
        path = self.base_dir / Path(*args)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def save_json(self, data, filename):
        """Save data as JSON"""
        filepath = self.base_dir / filename
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)
        return filepath

    def load_json(self, filename):
        """Load data from JSON"""
        filepath = self.base_dir / filename
        with open(filepath, 'r') as f:
            return json.load(f)

    def save_pickle(self, data, filename):
        """Save data as pickle"""
        filepath = self.base_dir / filename
        with open(filepath, 'wb') as f:
            pickle.dump(data, f)
        return filepath

    def load_pickle(self, filename):
        """Load data from pickle"""
        filepath = self.base_dir / filename
        with open(filepath, 'rb') as f:
            return pickle.load(f)
