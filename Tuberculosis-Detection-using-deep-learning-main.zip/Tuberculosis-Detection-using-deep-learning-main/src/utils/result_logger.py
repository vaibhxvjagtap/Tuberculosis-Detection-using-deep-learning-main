import json
from pathlib import Path
from datetime import datetime


class ResultLogger:
    """Log training and evaluation results"""

    def __init__(self, log_dir):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

    def log_epoch(self, epoch, train_metrics, val_metrics, fold=None):
        """Log metrics for an epoch"""
        if fold:
            filename = f'epoch_{epoch:03d}_fold{fold}_metrics.txt'
        else:
            filename = f'epoch_{epoch:03d}_metrics.txt'

        filepath = self.log_dir / filename

        with open(filepath, 'w') as f:
            f.write(f"Epoch: {epoch}\n")
            f.write(f"Timestamp: {datetime.now()}\n")
            f.write("=" * 60 + "\n\n")

            f.write("TRAINING METRICS:\n")
            for key, value in train_metrics.items():
                f.write(f"  {key:<35} {float(value):.6f}\n")

            f.write("\nVALIDATION METRICS:\n")
            for key, value in val_metrics.items():
                f.write(f"  {key:<35} {float(value):.6f}\n")

    def log_test_results(self, test_metrics, fold=None):
        """Log final test results"""
        if fold:
            filename = f'test_results_fold{fold}.txt'
        else:
            filename = 'test_results.txt'

        filepath = self.log_dir / filename

        with open(filepath, 'w') as f:
            f.write("TEST RESULTS\n")
            f.write(f"Timestamp: {datetime.now()}\n")
            f.write("=" * 60 + "\n\n")

            for key, value in test_metrics.items():
                f.write(f"{key:<40} {float(value):.6f}\n")

        return filepath
