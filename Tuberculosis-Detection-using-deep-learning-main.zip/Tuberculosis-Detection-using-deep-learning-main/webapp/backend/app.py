import os
import cv2
import numpy as np
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from PIL import Image
import uuid
from pathlib import Path
import tensorflow as tf

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Load models
print("Loading models...")
unet_model = tf.keras.models.load_model('models/unet_segmentation/best_unet_model.h5')
xception_model = tf.keras.models.load_model('models/xception_classification/best_xception_model.h5')

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy'})

@app.route('/api/upload', methods=['POST'])
def upload_image():
    """Upload chest X-ray image"""
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    file = request.files['image']
    image_id = str(uuid.uuid4())

    # Save image
    filepath = os.path.join(UPLOAD_FOLDER, f'{image_id}.png')
    file.save(filepath)

    return jsonify({'image_id': image_id})

@app.route('/api/analyze/<image_id>', methods=['GET'])
def analyze_image(image_id):
    """Analyze X-ray: segment lung and classify TB"""
    try:
        # Load image
        image_path = os.path.join(UPLOAD_FOLDER, f'{image_id}.png')
        if not os.path.exists(image_path):
            return jsonify({'error': 'Image not found'}), 404

        # Read image (grayscale), resize to model expected size
        image_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        image_gray_resized = cv2.resize(image_gray, (224, 224))
        image_gray_normalized = image_gray_resized.astype(np.float32) / 255.0
        image_gray_input = np.expand_dims(image_gray_normalized, axis=(0, -1))  # shape (1,224,224,1)

        # ========== STEP 1: Segmentation (UNet) ==========
        mask_pred = unet_model.predict(image_gray_input, verbose=0)  # expected shape (1, H, W, 1)
        # get the single prediction and channel
        mask_single = mask_pred[0, :, :, 0]
        mask_binary = (mask_single > 0.5).astype(np.uint8) * 255  # shape (224,224), values 0 or 255

        # Apply mask to original (resized) image
        image_rgb = cv2.cvtColor(image_gray_resized, cv2.COLOR_GRAY2RGB)
        segmented_lung = image_rgb.copy()
        # mask_binary==0 indicates background; set those pixels to 0
        segmented_lung[mask_binary == 0] = 0

        # Save segmented image
        seg_path = os.path.join(OUTPUT_FOLDER, f'{image_id}_segmented.png')
        cv2.imwrite(seg_path, segmented_lung)

        # Save mask
        mask_path = os.path.join(OUTPUT_FOLDER, f'{image_id}_mask.png')
        cv2.imwrite(mask_path, mask_binary)

        # ========== STEP 2: Classification (Xception) ==========
        # Xception expects 3-channel input, normalized
        image_rgb_normalized = segmented_lung.astype(np.float32) / 255.0
        image_xception_input = np.expand_dims(image_rgb_normalized, axis=0)  # shape (1,224,224,3)

        prediction_probs = xception_model.predict(image_xception_input, verbose=0)  # shape (1, num_classes)
        tb_probability = float(prediction_probs[0][1])   # Class 1 = TB (assuming this ordering)
        normal_probability = float(prediction_probs[0][0])  # Class 0 = Normal

        # Determine classification
        prediction_class = 'TB' if tb_probability > normal_probability else 'Normal'
        confidence = max(tb_probability, normal_probability)

        # ========== STEP 3: Generate Heatmap (Grad-CAM) ==========
        heatmap_colored = generate_gradcam_heatmap(image_rgb_normalized, xception_model)
        heatmap_path = os.path.join(OUTPUT_FOLDER, f'{image_id}_heatmap.png')
        cv2.imwrite(heatmap_path, heatmap_colored)

        return jsonify({
            'image_id': image_id,
            'prediction': prediction_class,
            'confidence': float(confidence),
            'tb_probability': float(tb_probability),
            'normal_probability': float(normal_probability),
            'stage': 'Active TB' if prediction_class == 'TB' else 'Normal',
            'urls': {
                'original': f'/api/image/{image_id}/original',
                'segmented': f'/api/image/{image_id}/segmented',
                'mask': f'/api/image/{image_id}/mask',
                'heatmap': f'/api/image/{image_id}/heatmap'
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/image/<image_id>/<image_type>', methods=['GET'])
def get_image(image_id, image_type):
    """Get processed image"""
    try:
        if image_type == 'original':
            filepath = os.path.join(UPLOAD_FOLDER, f'{image_id}.png')
        else:
            filepath = os.path.join(OUTPUT_FOLDER, f'{image_id}_{image_type}.png')

        if not os.path.exists(filepath):
            return jsonify({'error': 'Image not found'}), 404

        return send_file(filepath, mimetype='image/png')
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def generate_gradcam_heatmap(image, model, layer_name='block14_sepconv2_act'):
    """
    Generate Grad-CAM heatmap.
    `image` expected shape: (224,224,3) normalized float32 [0,1]
    """
    try:
        # Build a model that maps the input to the activations of the target layer
        grad_model = tf.keras.models.Model(
            inputs=[model.inputs],
            outputs=[model.get_layer(layer_name).output, model.output]
        )

        img_tensor = np.expand_dims(image, axis=0)  # (1,224,224,3)

        with tf.GradientTape() as tape:
            conv_outputs, predictions = grad_model(img_tensor)
            # predictions shape (1, num_classes)
            pred_index = tf.argmax(predictions[0])
            class_channel = predictions[:, pred_index]

        # gradients of the top predicted class w.r.t. the feature map activations
        grads = tape.gradient(class_channel, conv_outputs)
        # global-average-pool the gradients over the spatial locations
        pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

        # Get the convolution outputs for the single example
        conv_outputs = conv_outputs[0]  # shape (H, W, C)
        # Multiply each channel by the corresponding pooled gradient
        # conv_outputs @ pooled_grads -> produces (H, W, 1)
        heatmap = tf.matmul(conv_outputs, pooled_grads[..., tf.newaxis])
        heatmap = tf.squeeze(heatmap)

        # Normalize heatmap to [0,1]
        heatmap = tf.maximum(heatmap, 0) / (tf.math.reduce_max(heatmap) + 1e-8)
        heatmap_np = heatmap.numpy()

        # Resize to match original image size
        heatmap_resized = cv2.resize(heatmap_np, (224, 224))
        heatmap_uint8 = np.uint8(255 * heatmap_resized)

        # Apply color map (OpenCV expects single-channel 8-bit)
        heatmap_colored = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)  # BGR

        # Optionally overlay heatmap onto the original image
        original_bgr = np.uint8_
