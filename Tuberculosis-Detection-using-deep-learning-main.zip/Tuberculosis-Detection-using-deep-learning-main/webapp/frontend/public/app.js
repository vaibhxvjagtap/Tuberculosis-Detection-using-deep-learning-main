const { useState, useEffect } = React;

function TBDetectionApp() {
    const [selectedFile, setSelectedFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState(null);
    const [error, setError] = useState(null);

    const [chatMessages, setChatMessages] = useState([
        { type: "bot", text: "Hello! I am your TB Detection Assistant. Upload a chest X-ray to begin." }
    ]);

    const [chatInput, setChatInput] = useState("");

    // ----------------- FILE SELECTION -----------------
    const handleFileSelect = (event) => {
        setSelectedFile(event.target.files[0]);
        setError(null);
    };

    // ----------------- FILE UPLOAD + ANALYSIS -----------------
    const handleUpload = async () => {
        if (!selectedFile) {
            setError("Please select an image");
            return;
        }

        setLoading(true);
        setError(null);

        try {
            // Upload image
            const formData = new FormData();
            formData.append("image", selectedFile);

            const uploadRes = await fetch("http://localhost:5000/api/upload", {
                method: "POST",
                body: formData,
            });

            const uploadData = await uploadRes.json();
            const imageId = uploadData.image_id;

            // Analyze image
            const analyzeRes = await fetch(`http://localhost:5000/api/analyze/${imageId}`);
            const analysisData = await analyzeRes.json();

            setResults(analysisData);

            // Add bot message
            const botMessage = `I've analyzed the X-ray. Prediction: ${analysisData.prediction}, Confidence: ${(analysisData.confidence * 100).toFixed(2)}%`;
            setChatMessages((prev) => [...prev, { type: "bot", text: botMessage }]);

        } catch (err) {
            setError(`Analysis failed: ${err.message}`);
            setChatMessages((prev) => [...prev, { type: "bot", text: `Error: ${err.message}` }]);
        } finally {
            setLoading(false);
        }
    };

    // ----------------- CHATBOT -----------------
    const handleChatSend = () => {
        if (!chatInput.trim()) return;

        // Add user message
        setChatMessages((prev) => [...prev, { type: "user", text: chatInput }]);

        let response = "";

        if (results) {
            const input = chatInput.toLowerCase();

            if (input.includes("heatmap") || input.includes("red area")) {
                response = "The heatmap highlights regions the AI considered important. Red and orange zones show strong TB-related patterns.";
            } else if (input.includes("confidence")) {
                response = `The model is ${(results.confidence * 100).toFixed(2)}% confident in its prediction.`;
            } else if (input.includes("segmentation")) {
                response = "The segmentation image isolates the lung region so the AI can focus on the relevant anatomical areas.";
            } else {
                response = "I can help explain the heatmap, confidence scores, or segmentation results!";
            }
        } else {
            response = "Please upload and analyze an X-ray image first.";
        }

        setChatMessages((prev) => [...prev, { type: "bot", text: response }]);
        setChatInput("");
    };

    // ----------------- UI -----------------
    return (
        <div className="container">

            <header>
                <h1>��� TB Detection System</h1>
                <p>AI-Powered Tuberculosis Detection from Chest X-Rays</p>
            </header>

            <main>

                {/* Upload Section */}
                <div className="upload-section">
                    <div className="upload-area">
                        <div className="upload-icon">���</div>

                        <label htmlFor="file-input">
                            <div className="upload-text">Drag and drop your chest X-ray image here</div>
                            <div className="upload-subtext">or click to browse (PNG, JPG)</div>

                            <input
                                id="file-input"
                                type="file"
                                accept="image/*"
                                onChange={handleFileSelect}
                            />
                        </label>

                        {selectedFile && (
                            <div style={{ marginTop: "10px" }}>
                                Selected: {selectedFile.name}
                            </div>
                        )}
                    </div>

                    <button
                        onClick={handleUpload}
                        disabled={loading || !selectedFile}
                    >
                        {loading ? (
                            <>
                                <span className="loading"></span>
                                Analyzing...
                            </>
                        ) : (
                            "��� Analyze Image"
                        )}
                    </button>
                </div>

                {/* Error Message */}
                {error && <div className="error-message">{error}</div>}

                {/* Results Section */}
                {results && (
                    <div className="results-section">

                        <div className="result-card">
                            <div className="result-title">Diagnosis Result</div>

                            <div
                                className={`prediction-result ${
                                    results.prediction === "TB" ? "positive" : "negative"
                                }`}
                            >
                                {results.prediction}
                            </div>

                            <div className="confidence">
                                Confidence: {(results.confidence * 100).toFixed(2)}%
                            </div>

                            <div className="confidence-bar">
                                <div
                                    className="confidence-fill"
                                    style={{ width: `${results.confidence * 100}%` }}
                                ></div>
                            </div>

                            <div>
                                TB Probability: {(results.tb_probability * 100).toFixed(2)}% <br />
                                Normal Probability: {(results.normal_probability * 100).toFixed(2)}%
                            </div>
                        </div>

                        {/* Images Grid */}
                        <div className="images-grid">
                            <div className="image-container">
                                <img src={`http://localhost:5000${results.urls.original}`} alt="Original" />
                                <div className="image-label">Original X-ray</div>
                            </div>

                            <div className="image-container">
                                <img src={`http://localhost:5000${results.urls.segmented}`} alt="Segmented" />
                                <div className="image-label">Segmented Lung</div>
                            </div>

                            <div className="image-container">
                                <img src={`http://localhost:5000${results.urls.mask}`} alt="Mask" />
                                <div className="image-label">Lung Mask</div>
                            </div>
                        </div>

                        {/* Heatmap */}
                        <div className="heatmap-section">
                            <div className="heatmap-title">Grad-CAM Heatmap Visualization</div>

                            <img
                                src={`http://localhost:5000${results.urls.heatmap}`}
                                alt="Heatmap"
                                style={{ width: "100%", borderRadius: "10px", marginTop: "10px" }}
                            />

                            <div className="heatmap-explanation">
                                The heatmap shows which regions of the lung the AI model considered important.
                                Red and orange regions indicate areas with higher attention.
                            </div>
                        </div>

                        {/* Chatbot */}
                        <div className="chatbot-section">
                            <div className="result-title">��� Ask Questions</div>

                            <div className="chat-messages">
                                {chatMessages.map((msg, idx) => (
                                    <div
                                        key={idx}
                                        className={`message ${msg.type}`}
                                    >
                                        <div className="message-bubble">
                                            {msg.text}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="chat-input-group">
                                <input
                                    type="text"
                                    placeholder="Ask me about the results..."
                                    value={chatInput}
                                    onChange={(e) => setChatInput(e.target.value)}
                                    onKeyDown={(e) => e.key === "Enter" && handleChatSend()}
                                />
                                <button onClick={handleChatSend}>Send</button>
                            </div>
                        </div>

                    </div>
                )}
            </main>
        </div>
    );
}

// Mount React app
ReactDOM.createRoot(document.getElementById("root")).render(<TBDetectionApp />);
